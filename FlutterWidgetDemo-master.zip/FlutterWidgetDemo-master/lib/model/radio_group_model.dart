class GroupModel {
  String text;
  int index;

  GroupModel({this.text, this.index});
}
