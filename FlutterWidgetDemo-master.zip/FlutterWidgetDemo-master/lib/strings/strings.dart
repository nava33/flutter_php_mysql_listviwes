class Strings {
  static String uname = "UserName";
  static String pwd = "Password";
}
