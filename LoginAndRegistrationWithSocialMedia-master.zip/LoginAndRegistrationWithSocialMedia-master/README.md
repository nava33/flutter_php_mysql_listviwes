# LoginAndRegistrationWithSocialMedia
Created a Project to design login screen, registration screen, login with google ,slider navigation drawer,dashboard screen login with Facebook using Flutter.

Step 1) Register application on google developer console https://console.developers.google.com and copy google-service.json

Step 2) Register application on facebook developer console https://developers.facebook.com/ and put the facebook app id and scheme into string.xml file.

![screenshot_1527760412](https://user-images.githubusercontent.com/3602601/42028848-29e1e348-7aeb-11e8-9f69-e252458e17b4.png)
![screenshot_1530180505](https://user-images.githubusercontent.com/3602601/42028850-2a3a9b00-7aeb-11e8-984b-47acb09b21c1.png)
![screenshot_1530180521](https://user-images.githubusercontent.com/3602601/42028855-2c0638b8-7aeb-11e8-8a57-a5330638e39b.png)
![screenshot_1530180621](https://user-images.githubusercontent.com/3602601/42028857-2ddd2f3e-7aeb-11e8-9374-66d3e266cc72.png)
![screenshot_1530181166](https://user-images.githubusercontent.com/3602601/42028859-2eea4b1e-7aeb-11e8-9cf3-b00c37f41965.png)
